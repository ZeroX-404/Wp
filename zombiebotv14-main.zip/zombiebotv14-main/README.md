# zombiebotv14
python based latest zombie bot v.14
##Install Python 2.7 To Run All Tools

##Module :

##-pip3 install -r requirements.txt

##[Zombi Bot V14  - Only work for python 2.7]

##Module :

##-pip install request
##-pip install requests
##-pip install colorama
##-pip install bs4
##-pip install tldextract

Educational purpose only use it with your risk
![Ekran Alıntısı](https://user-images.githubusercontent.com/42300174/112203000-3b8db080-8c3c-11eb-83b4-b13a7129c9c5.PNG)

